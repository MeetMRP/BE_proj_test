import React from 'react';

const Footer = () => {
  return <footer>© 2025 MyWebGen. All rights reserved.</footer>;
};

export default Footer;
